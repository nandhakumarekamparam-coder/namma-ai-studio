import {useState} from "react";
import {AudioLines,Clapperboard,Film,Folder,Image,Images,Menu,Settings,Sparkles,Users,WandSparkles,Plus,LoaderCircle} from "lucide-react";
import {submitGeneration} from "./lib/api";

const tools=[
 ["text-to-video","Text to Video",Film,"Turn a prompt into a video concept"],
 ["image-to-video","Image to Video",Image,"Animate an image"],
 ["image","AI Image",Images,"Create an image from text"],
 ["voice","AI Voice",AudioLines,"Prepare a voice generation request"],
 ["storyboard","Storyboard",Clapperboard,"Break a story into scenes"],
 ["character","Characters",Users,"Plan consistent characters"]
];
export default function App(){
 const [active,setActive]=useState("text-to-video"),[prompt,setPrompt]=useState(""),[ratio,setRatio]=useState("9:16"),[duration,setDuration]=useState("5"),[quality,setQuality]=useState("standard"),[busy,setBusy]=useState(false),[notice,setNotice]=useState(""),[history,setHistory]=useState([]),[menu,setMenu]=useState(false);
 const selected=tools.find(t=>t[0]===active)||tools[0], Icon=selected[2];
 async function create(){
  if(!prompt.trim())return; setBusy(true);setNotice("");
  try{const job=await submitGeneration({tool:active,prompt:prompt.trim(),aspect_ratio:ratio,duration_seconds:Number(duration),quality});setHistory(h=>[job,...h].slice(0,8));setNotice(job.result?.notice||job.message);}
  catch(e){setNotice(`Backend connection error: ${e.message}. Start the API server first.`);}
  finally{setBusy(false);}
 }
 return <div className="shell">
  <aside className={`sidebar ${menu?"open":""}`}><div className="brand"><span className="brand-icon"><WandSparkles/></span><div><b>Namma AI Studio</b><small>Creative workspace</small></div></div>
   <p className="side-label">CREATE</p>{tools.map(([id,label,I])=><button key={id} className={`nav ${active===id?"selected":""}`} onClick={()=>{setActive(id);setMenu(false)}}><I size={18}/>{label}</button>)}
   <div className="side-bottom"><div className="mode"><i/> Prototype mode<small>Mock provider</small></div><button className="nav"><Folder size={18}/>My projects</button><button className="nav"><Settings size={18}/>Settings</button></div>
  </aside>
  {menu&&<button className="scrim" onClick={()=>setMenu(false)}/>}
  <main><header><button className="hamb" onClick={()=>setMenu(true)}><Menu/></button><span>Workspace / <b>{selected[1]}</b></span><span className="ready">● API prototype</span></header>
   <div className="content"><section className="hero"><div className="eyebrow"><Sparkles size={14}/> YOUR CREATIVE AI WORKSPACE</div><h1>Make your next<br/>big idea happen.</h1><p>உங்கள் கற்பனையை உருவாக்கத் தொடங்குங்கள்.</p></section>
    <div className="heading"><div><h2>Choose your creation tool</h2><p>Start with a tool and describe what you want.</p></div></div>
    <div className="tools">{tools.map(([id,label,I,desc])=><button key={id} className={`tool ${active===id?"chosen":""}`} onClick={()=>setActive(id)}><span><I size={20}/></span><b>{label}</b><small>{desc}</small></button>)}</div>
    <section className="studio"><div className="studio-head"><span className="large-icon"><Icon/></span><div><h2>{selected[1]}</h2><p>{selected[3]}</p></div><em>BETA</em></div>
     <label htmlFor="prompt">Describe your idea</label><textarea id="prompt" value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="உங்கள் காட்சியை விவரிக்கவும்... Example: A cinematic sunrise over misty green mountains..."/>
     <div className="fields"><div><label>Aspect ratio</label><select value={ratio} onChange={e=>setRatio(e.target.value)}><option>9:16</option><option>16:9</option><option>1:1</option></select></div><div><label>Quality</label><select value={quality} onChange={e=>setQuality(e.target.value)}><option value="draft">Draft</option><option value="standard">Standard</option><option value="high">High</option></select></div><div><label>Duration</label><select value={duration} onChange={e=>setDuration(e.target.value)}><option value="5">5 sec</option><option value="10">10 sec</option><option value="15">15 sec</option><option value="30">30 sec</option></select></div></div>
     <div className="create-row"><small>✦ Describe your scene clearly</small><button className="create" disabled={!prompt.trim()||busy} onClick={create}>{busy?<LoaderCircle className="spin" size={17}/>:<Plus size={17}/>}Create</button></div>
     {notice&&<div className="notice" role="status">{notice}</div>}<p className="disclaimer">Prototype only: mock mode checks the workflow; it does not render actual media.</p>
    </section>
    <section className="recent"><h2>Recent activity</h2>{history.length===0?<div className="empty">No projects yet. Your first creation starts here.</div>:history.map(j=><div className="history" key={j.id}><Film size={18}/><div><b>{j.tool}</b><small>{j.message}</small></div><span>{j.status}</span></div>)}</section>
    <footer>© 2026 Namma AI Studio · Built for creators</footer>
   </div>
  </main>
 </div>
}
