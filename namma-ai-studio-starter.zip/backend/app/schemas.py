from typing import Literal
from pydantic import BaseModel, Field

ToolType = Literal["text-to-video", "image-to-video", "image", "voice", "storyboard", "character"]

class GenerateRequest(BaseModel):
    tool: ToolType
    prompt: str = Field(min_length=1, max_length=8000)
    aspect_ratio: Literal["9:16", "16:9", "1:1"] = "9:16"
    quality: Literal["draft", "standard", "high"] = "standard"
    duration_seconds: int = Field(default=5, ge=1, le=30)
