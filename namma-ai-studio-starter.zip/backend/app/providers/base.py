from abc import ABC, abstractmethod
from app.schemas import GenerateRequest

class GenerationProvider(ABC):
    @abstractmethod
    async def generate(self, request: GenerateRequest) -> dict:
        # Implement an authorized real model integration here.
        raise NotImplementedError
