from app.providers.base import GenerationProvider

class MockProvider(GenerationProvider):
    async def generate(self, request):
        # No fake media URL: this only confirms the API workflow.
        return {
            "mode": "mock",
            "preview_only": True,
            "notice": "Backend connected. Configure a real model to generate media.",
            "submitted_prompt": request.prompt
        }
