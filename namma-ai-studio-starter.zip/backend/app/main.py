from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.schemas import GenerateRequest
from app.services.jobs import create_job, get_job

app = FastAPI(title="Namma AI Studio API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=settings.allowed_origins,
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.get("/api/health")
async def health():
    return {"ok": True, "app": "Namma AI Studio", "environment": settings.app_env}

@app.get("/api/capabilities")
async def capabilities():
    return {"provider": settings.generation_provider, "prototype_only": True,
            "tools": ["text-to-video", "image-to-video", "image", "voice", "storyboard", "character"],
            "note": "Mock mode tests workflow only; connect a real provider for media generation."}

@app.post("/api/generate")
async def generate(request: GenerateRequest):
    return await create_job(request)

@app.get("/api/jobs/{job_id}")
async def job_status(job_id: str):
    job = get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job
