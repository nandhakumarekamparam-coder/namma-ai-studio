from uuid import uuid4
from app.providers.mock import MockProvider

_jobs = {}
_provider = MockProvider()

async def create_job(request):
    job_id = str(uuid4())
    job = {"id": job_id, "status": "running", "tool": request.tool,
           "message": "Request received.", "result": None}
    _jobs[job_id] = job
    try:
        result = await _provider.generate(request)
        job.update(status="completed", message="Prototype request processed.", result=result)
    except Exception as exc:
        job.update(status="failed", message="Generation failed.", result={"error": str(exc)})
    return job

def get_job(job_id):
    return _jobs.get(job_id)
