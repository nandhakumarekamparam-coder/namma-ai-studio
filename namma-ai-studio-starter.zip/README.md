# Namma AI Studio

Mobile-first AI video studio starter: React/Vite frontend + FastAPI backend.

## Run locally
Requirements: Node.js 20+, Python 3.11+.

Backend:
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```
API docs: http://localhost:8000/docs

Frontend (second terminal):
```bash
cd frontend
npm install
npm run dev -- --host 0.0.0.0
```
Open the Vite URL printed in the terminal. For phone testing on the same Wi-Fi, use your computer's LAN IP and Vite port.

## Important
The included `mock` provider is only for testing the UI/API workflow. It does not create actual images, voices, or videos. A real model provider must be connected in the backend. Self-hosted video models need suitable GPU hardware; hosting and electricity can cost money. Keep all provider secrets on the backend, never in frontend code.

## Next steps
1. Choose a self-hostable model after checking GPU/VRAM requirements and license.
2. Implement its adapter under `backend/app/providers/`.
3. Add secure login, database, uploads, storage, background workers and job cancellation.
4. Deploy with HTTPS.
